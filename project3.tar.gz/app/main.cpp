#include "HashMap.hpp"
#include <iostream>
#include <string>
#include <sstream>

int main()
{
    std::string input;
    HashMap test;
    do{
        //std::cin>>input;
        std::getline(std::cin,input);

        std::string i,a,b;
        std::stringstream ss(input);
        ss>>i;
        if(i == "CREATE")
        {
            ss>>a;
            ss>>b;
            if(test.contains(a) == true)
            {
                std::cout<<"EXISTS"<<std::endl;
            }
            else
            {
                if(b == "")
                {
                    std::cout<<"INVALID"<<std::endl;
                }
                else
                {
                    test.add(a,b);
                    std::cout<<"CREATED"<<std::endl;
                }
            }
        }
        else if( i == "DEBUG")
        {
            ss>>a;
            if(a == "ON")
            {
                if(test.debugg() == true)
                {
                    std::cout<<"ON ALREADY"<<std::endl;
                }
                else
                {
                    test.debug("ON");
                    std::cout<<"ON NOW"<<std::endl;
                }
            }
            if(a == "OFF")
            {
                if(test.debugg() == false)
                {
                    std::cout<<"OFF ALREADY"<<std::endl;
                }
                else
                {
                    test.debug("OFF");
                    std::cout<<"OFF NOW"<<std::endl;
                }
            }
        }
        else if(i == "LOGIN")
        {
            ss>>a;
            ss>>b;
            if(a == "COUNT" && b=="")
            {
                if(test.debugg() == true)
                    std::cout<<test.size()<<std::endl;
                else
                    std::cout<<"INVALID"<<std::endl;
            }
            else
            {
                if(test.contains(a)==true)
                {
                    if(b == "")
                    {
                        std::cout<<"INVALID"<<std::endl;
                    }
                    else if(test.value(a) == b)
                    {
                        std::cout<<"SUCCEEDED"<<std::endl;
                    }
                    else
                    {
                        std::cout<<"FAILED"<<std::endl;
                    }
                }
                else if(a != "" && b != "")
                {
                    std::cout<<"FAILED"<<std::endl;
                }
                else
                {
                    std::cout<<"INVALID"<<std::endl;
                }
            }
        }
        else if(i == "REMOVE")
        {
            ss>>a;
            if(test.contains(a) == true)
            {
                test.remove(a);
                std::cout<<"REMOVED"<<std::endl;
            }
            else
            {
                std::cout<<"NONEXISTENT"<<std::endl;
            }
        }
        else if(i == "QUIT")
        {
            std::cout<<"GOODBYE"<<std::endl;
        }
        else if(i == "MAX")
        {
            ss>>a;
            ss>>b;
            if(a == "BUCKET" && b == "SIZE")
            {
                std::cout<<test.maxBucketSize()<<std::endl;
            }
            else
            {
                std::cout<<"INVALID"<<std::endl;
            }
        }
        else if(i == "BUCKET")
        {
            ss>>a;
            if(a == "COUNT")
            {
                std::cout<<test.bucketCount()<<std::endl;
            }
            else
            {
                std::cout<<"INVALID"<<std::endl;
            }
        }
        else if(i == "LOAD")
        {
            ss>>a;
            if(a == "FACTOR")
            {
                std::cout<<test.loadFactor()<<std::endl;
            }
        }
        else if(i == "CLEAR")
        {
            ss>>a;
            ss>>b;
            if(a == "" && b == "")
            {
                test.~HashMap();
            }
        }
        else
        {
            std::cout<<"INVALID"<<std::endl;
        }
    }while(input!="QUIT");
    return 0;
}
