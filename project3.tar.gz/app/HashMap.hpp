#ifndef HASHMAP_HPP
#define HASHMAP_HPP

#include <functional>
#include <string>



class HashMap
{
public:

    using HashFunction = std::function<unsigned int(const std::string&)>;
    static constexpr unsigned int INITIAL_BUCKET_COUNT = 10;


public:
    HashMap();
    HashMap(HashFunction hashFunction);
    HashMap(const HashMap& hm);
    ~HashMap();
    HashMap& operator=(const HashMap& hm);
    void add(const std::string& key, const std::string& value);
    bool remove(const std::string& key);
    bool contains(const std::string& key) const;
    std::string value(const std::string& key) const;
    unsigned int size() const;
    unsigned int bucketCount() const;
    double loadFactor() const;
    unsigned int maxBucketSize() const;
    void rehash();
    void debug(const std::string& val);
    bool debugg();

private:
    struct Node
    {
        std::string key;
        std::string value;
        Node* next;
    };
    Node** HashTable;
    unsigned int bucket;
    unsigned int s;
    HashFunction hashFunction;
    bool debugger = false;
    };



#endif

