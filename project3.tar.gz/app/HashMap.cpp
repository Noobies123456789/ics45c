#include "HashMap.hpp"
#include <functional>
#include <string>
#include <iostream>

namespace
{
unsigned int hashing(const std::string& str)
{
    unsigned int a = 0;
    for (int i = 0; i < str.length(); i++)
        a += int(str.at(i));
    return  a; 
}
}
HashMap::HashMap()
    : HashTable{new Node*[INITIAL_BUCKET_COUNT]()},bucket{INITIAL_BUCKET_COUNT},s{0},hashFunction{hashing}
{

}
HashMap::HashMap(HashFunction hf)
    : HashTable{new Node*[INITIAL_BUCKET_COUNT]()}, bucket{INITIAL_BUCKET_COUNT},s{0},hashFunction{hf}
{

}
HashMap::HashMap(const HashMap& hm)
    : HashTable{new Node*[hm.bucket]()},bucket{hm.bucket},s{hm.s},hashFunction{hm.hashFunction}
{
    for(unsigned int i = 0; i < hm.bucket; i++)
    {
        Node* n = hm.HashTable[i];
        Node** h = &HashTable[i];
        *h = NULL;
        while(n)
        {
            Node* c = new Node;
            c->key = n->key;
            c->value = n->value;
            c->next = NULL;
            *h = c;
            h=&c->next;
            n=n->next;

        }
    }
    

}
HashMap::~HashMap()
{
    Node* a;
    Node* c;
    for(unsigned int i =0;i<bucket;i++)
    {
        c = HashTable[i];
        while(c != nullptr)
        {
            a = c;
            c = a->next;
            delete a;
        }
    }
    delete[] HashTable;
}

HashMap& HashMap::operator=(const HashMap& hm)
{
    Node** table = new Node*[hm.bucket]();
    for(unsigned int i = 0;i<hm.bucket;i++)
        {
            while(hm.HashTable[i])
            {
                if(hm.HashTable[i] != nullptr)
                {
                    Node* clown = nullptr;
                    if(table[hashFunction(hm.HashTable[i]->key)%(bucket)] == nullptr)
                    {
                        table[hashFunction(hm.HashTable[i]->key)%(bucket)] = hm.HashTable[i];
                    }
                    else
                    {
                        
                        while(table[hashFunction(hm.HashTable[i]->key)%(bucket)]->next != nullptr)
                        {
                            table[hashFunction(hm.HashTable[i]->key)%(bucket)] = table[hashFunction(hm.HashTable[i]->key)%(bucket)]->next;
                        }
                        clown->key = hm.HashTable[i]->key;
                        clown->value = hm.HashTable[i]->value;
                        clown->next = NULL;
                        table[hashFunction(hm.HashTable[i]->key)%(bucket)]->next = clown;
                    }
                    hm.HashTable[i] = hm.HashTable[i]->next;
                }
            }
        }
        bucket = hm.bucket;
        s = hm.s;
        delete[] HashTable;
        HashTable = table;
    return *this;
}

void HashMap::rehash()
{
    Node** table = new Node*[bucket*2+1];
    for(unsigned int i =0;i<bucket;i++)
    {
        Node* c = HashTable[i];
        while(c != nullptr)
        {
            Node* clown = c;
            Node* &b = table[hashFunction(clown->key)%(bucket*2+1)];
            c = c->next;
            clown->next = b;
            b = clown;
        }
    }
    delete[] HashTable;
    HashTable = table;
    bucket = bucket*2+1;
}

void HashMap::add(const std::string& key, const std::string& value)
{
    if(contains(key))
    {
        return;
    }
    if(loadFactor() >= 0.8)
    {
        rehash();
    }
    s++;
    Node* lol = HashTable[hashFunction(key)%bucket];
    Node* head = lol;
    if(head == nullptr)
    {
        Node* clown = new Node();
        clown->key = key;
        clown->value = value;
        clown->next = NULL;
        HashTable[hashFunction(key)%bucket] = clown;
    }
    else
    {
        Node* clown = new Node();
        while(head->next != nullptr)
        {
            head = head->next;
        }
        clown->key = key;
        clown->value = value;
        clown->next = lol;
        HashTable[hashFunction(key)%bucket] = clown;        
    }
}

bool HashMap::remove(const std::string& key)
{
    for(unsigned int i = 0;i<bucket;i++)
    {
        Node* c = HashTable[i];
	    while(c) 
        {
            Node* a = c;
		    if(c->key == key) 
            {
                HashTable[i] = c->next;
                delete a;
                s-=1;
                return true;
            }
		    c = c->next;
	    }
    }
    return false;
}

bool HashMap::contains(const std::string& key) const
{
    for(unsigned int i = 0;i<bucket;i++)
    {
        Node* c = HashTable[i];
	    while(c) 
        {
		    if(c->key == key) 
            {
                return true;
            }
		    c = c->next;
	    }
    }
    return false;
}

std::string HashMap::value(const std::string& key) const
{
    
    for(unsigned int i = 0;i<bucket;i++)
    {
        Node* c = HashTable[i];
	    while(c) 
        {
		    if(c->key == key) 
            {
                return c->value;
            }
		    c = c->next;
	    }
    }
    return "";
}

double HashMap::loadFactor() const
{
    return HashMap::s/double(HashMap::bucket);
}

unsigned int HashMap::size() const
{
    return HashMap::s;
}

unsigned int HashMap::bucketCount() const
{
    return HashMap::bucket;
}

unsigned int HashMap::maxBucketSize() const
{
    unsigned int max = 0;
    for(unsigned int i =0; i <bucket;i++)
    {
        Node* c = HashTable[i];
        unsigned int x = 0;
	    while(c != nullptr) 
        {
            x++;
		    c = c->next;
        }
        if(max < x)
        {
            max = x;
        }
    }
    return max;
}

void HashMap::debug(const std::string& val)
{
    if(val == "ON")
    {
        debugger = true;
    }
    if(val == "OFF")
    {
        debugger = false;
    }
}

bool HashMap::debugg()
{
    return debugger;
}