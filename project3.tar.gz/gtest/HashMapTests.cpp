// HashMapTests.cpp
//
// ICS 45C Fall 2021
// Project #3: Maps and Legends
//
// Write unit tests for your HashMap class here.  I've provided a few tests
// already, though I've commented them out, because they won't compile and
// link until you've implemented some things.
//
// Of course, you'll want to write lots more of these tests yourself, because
// this is an inexpensive way to know whether things are working the way
// you expect -- including scenarios that you won't happen to hit in the
// course of testing your overall program.  (You might also want to be sure
// that your HashMap implementation is complete and correct before you try
// to write the rest of the program around it, anyway; there's a very
// substantial amount of partial credit available if all that works is
// HashMap.)

#include <gtest/gtest.h>
#include "HashMap.hpp"


TEST(HashMapTests, sizeOfNewlyCreatedHashMapIsZero)
{
    HashMap empty;
    ASSERT_EQ(0, empty.size());
}


TEST(HashMapTests, emptyMapContainsNoKeys)
{
    HashMap empty;
    ASSERT_FALSE(empty.contains("first"));
    ASSERT_FALSE(empty.contains("second"));
}


TEST(HashMapTests, containKeyAfterAddingIt)
{
    HashMap hm;
    hm.add("Boo", "perfect");
    ASSERT_TRUE(hm.contains("Boo"));
}

TEST(HashMapTests, KeyToValue)
{
    HashMap hm;
    hm.add("Boo","looking");
    ASSERT_EQ("looking",hm.value("Boo"));
}

TEST(HashMapTests, CopyMap)
{
    HashMap hm;
    hm.add("Boo","playing");
    HashMap hm1=hm;
    ASSERT_TRUE(hm1.contains("Boo"));
    ASSERT_EQ("playing",hm1.value("Boo"));
}

TEST(HashMapTests, OverloadEq)
{
    HashMap hm;
    hm.add("Boo","playing");
    HashMap hm1;
    hm1 = hm;
    ASSERT_TRUE(hm1.contains("Boo"));
    ASSERT_EQ("playing",hm1.value("Boo"));
}

TEST(HashMapTests, removekey)
{
    HashMap hm;
    hm.add("Boo","eating");
    ASSERT_TRUE(hm.contains("Boo"));
    hm.remove("Boo");
    ASSERT_FALSE(hm.contains("Boo"));
}

TEST(HashMapTests, SizeKey)
{
    HashMap hm;
    hm.add("Boo","laying");
    hm.add("Bob","playing");
    ASSERT_EQ(2,hm.size());
    ASSERT_TRUE(hm.contains("Bob"));
}

TEST(HashMapTests, MaxBucketSizeKey)
{
    HashMap hm;
    hm.add("ivy","laying");
    hm.add("win","playing");
    hm.add("John","clown");
    ASSERT_EQ(2,hm.maxBucketSize());
    ASSERT_EQ(3,hm.size());
}

TEST(HashMapTests, BucketCounteKey)
{
    HashMap hm;
    hm.add("ivy","laying");
    hm.add("win","playing");
    hm.add("John","clown");
    hm.add("khine","laying");
    hm.add("zin","playing");
    hm.add("htet","clown");
    hm.add("alice","laying");
    hm.add("tzuyu","playing");
    hm.add("cha","cute");
    hm.add("chav","cute");
    ASSERT_EQ(21,hm.bucketCount());
    //ASSERT_EQ(0.8,hm.loadFactor());
}

TEST(HashMapTests, LoadKey)
{
    HashMap hm;
    hm.add("ivy","laying");
    hm.add("win","playing");
    hm.add("John","clown");
    hm.add("khine","laying");
    hm.add("zin","playing");
    hm.add("htet","clown");
    hm.add("alice","laying");
    hm.add("tzuyu","playing");
    ASSERT_EQ(0.8,hm.loadFactor());
}