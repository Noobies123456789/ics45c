#include <iostream>
#include <string>
#include <sstream>

struct students
{
    int number;
    char option;
    std::string name;
    double fnum;
};

struct marks
{
    int number;
    std::string scores;
};

struct cutpoints
{
    double a;
    double b;
    double c;
    double d;
};

void grades(std::string g,int* grade)
{
    std::stringstream s(g);
    int i = 0;
    while(s >> grade[i])
    {
        i++;
    }
}

void percentage(std::string p,int* percent)
{
    std::stringstream s(p);
    int j = 0;
    while(s >> percent[j])
    {
        j++;
    }
}

void student(int x, char y, std::string k,students* a,int t)
{
    a[t].number = x;
    a[t].option = y;
    a[t].name = k;
}

void mark(int x,std::string y, marks* z, int t)
{
    z[t].number = x;
    z[t].scores = y;
}

void cutpoint(double a,double b,double c,double d,cutpoints* x,int t)
{
    x[t].a = a;
    x[t].b = b;
    x[t].c = c;
    x[t].d = d;
}

double total(std::string x,int* y,int* z,int s)
{
    int* a = new int[s];
    double* res = new double[s];
    int n;
    int i = 0;
    std::stringstream b(x);
    while(b>>n)
    {
        a[i] = n;
        i++;
    }
    double score=0.0;
    for(int i =0;i<s;i++)
    {
        double div = (double)a[i]/(double)y[i];
        res[i] = div*z[i];
    }
    for(int i =0;i<s;i++)
    {
        score += (double)res[i];
    }
    free(res);
    free(a);
    return score;
}

std::string course(double d, int* x,int s,cutpoints* c,char y)
{
    int r =0;
    double m;
    for(int a=0;a<s;a++)
    {
        r+=x[a];
    }
    m = d/r * 100;
    if(y == 'G')
    {
        if(m>c->d)
        {
            if(m>c->c)
            {
                if(m>c->b)
                {
                    if(m>c->a)
                    {
                        return "A";
                    }
                    return "B";
                }
                return "C";
            }
            return "D";
        }
        return "F";
    }
    if(y == 'P')
    {
        if(m>c->d)
        {
            return "P";
        }
    }
    return "NP";
}

int main()
{
    int count = 0;
    int s = 0;
    int rs = 0;
    std::string g,p,a;
    std::string num,opt;
    std::cin>>count;
    int* grade = new int[count];
    int* percent = new int[count];
    std::string filler;
    std::getline(std::cin,filler);
    std::getline(std::cin,g);
    std::getline(std::cin,p);
    grades(g,grade);
    percentage(p,percent);
    
    std::cin>>s;
    students* studs = new students[s];
    std::getline(std::cin,filler);
    int track = 0;
    while(track < s)
    {
        std::cin>>num>>opt;
        std::getline(std::cin,a);
        a.erase(0,1);
        student(std::stoi(num),opt[0],a,studs,track);
        track++;
    }
    
    std::string r;
    int raw = 0;
    std::cin>>rs;
    marks* rawscore = new marks[rs];
    int trk = 0;
    while(trk < rs)
    {
        std::cin>>raw;
        std::getline(std::cin,r);
        r.erase(0,1);
        mark(raw,r,rawscore,trk);
        trk++;
    }

    int cp = 0;
    std::cin>>cp;
    int tk = 0;
    double aa = 0,bb = 0,cc = 0,dd = 0;
    cutpoints* cut = new cutpoints[cp];
    while(tk < cp)
    {
        std::cin>>aa>>bb>>cc>>dd;
        cutpoint(aa,bb,cc,dd,cut,tk);
        tk++;
    }

    for(int ttl = 0;ttl<s;ttl++)
    {
        int x = 0;
        for(int tl = 0;tl <rs;tl++)
        {
            if(rawscore[tl].number == studs[ttl].number)
            {
                x = tl;
            }
        }
        studs[ttl].fnum = total(rawscore[x].scores,grade,percent,count);
    }
    std::cout<<"TOTAL SCORES"<<std::endl;
    for(int ttl = 0;ttl<s;ttl++)
    {
        std::cout<<studs[ttl].number<<" "<<studs[ttl].name<<" "<<studs[ttl].fnum<<std::endl;
    }
    for(int tk =0;tk<cp;tk++)
    {
        cutpoints* c = &cut[tk];
        std::cout<<"CUTPOINT SET "<<tk+1<<std::endl;
        for(int ttl = 0;ttl<s;ttl++)
        {
            std::cout<<studs[ttl].number<<" "<<studs[ttl].name<<" "<<course(studs[ttl].fnum,percent,count,c,studs[ttl].option)<<std::endl;

        }
    }
    delete[] grade;
    delete[] percent;
    delete[] studs;
    delete[] rawscore;
    delete[] cut;
    return 0;
}

